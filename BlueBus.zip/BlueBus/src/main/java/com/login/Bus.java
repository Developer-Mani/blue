package com.login;

public class Bus {
	private String busNO , time, yourLocation, destination, fare;

	public String getBusNO() {
		return busNO;
	}

	public void setBusNO(String busNO) {
		this.busNO = busNO;
	}

	public String getTime() {
		return time;
	}

	public void setTime(String time) {
		this.time = time;
	}

	public String getYourLocation() {
		return yourLocation;
	}

	public void setYourLocation(String yourLocation) {
		this.yourLocation = yourLocation;
	}

	public String getDestination() {
		return destination;
	}

	public void setDestination(String destination) {
		this.destination = destination;
	}

	public String getFare() {
		return fare;
	}

	public void setFare(String fare) {
		this.fare = fare;
	}
}
